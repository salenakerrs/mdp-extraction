"""File reader module."""
