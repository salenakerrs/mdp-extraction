"""Shell script utility module."""
