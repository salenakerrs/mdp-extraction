"""Connectivity test module."""
