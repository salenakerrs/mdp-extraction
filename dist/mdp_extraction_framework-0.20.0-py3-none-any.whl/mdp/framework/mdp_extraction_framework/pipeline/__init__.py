"""Extraction framework pipelines."""
