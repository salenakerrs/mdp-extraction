"""Extraction Framework."""
__version__ = "0.20.0"  # will be overwritten by poetry_bumpversion
