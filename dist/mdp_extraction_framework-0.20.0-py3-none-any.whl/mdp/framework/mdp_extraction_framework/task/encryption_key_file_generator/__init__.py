"""Encryption key retriever Modules."""
